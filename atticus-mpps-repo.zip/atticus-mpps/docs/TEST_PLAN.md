# Test Plan v0.1

Required tests:

- SHA-256 determinism
- Packet schema validation
- Missing field rejection
- Candidate parentage
- Replay determinism
- Review-state guardrails
