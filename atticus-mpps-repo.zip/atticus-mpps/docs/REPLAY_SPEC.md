# Replay Spec v0.1

Replay must reconstruct candidate outputs from raw packet logs and raw asset hashes.

Pass condition:

- Same raw input hash
- Same algorithm version
- Same calibration reference
- Same candidate value
- Same parent lineage

Replay divergence must produce a report rather than silently passing.
