from __future__ import annotations

from pathlib import Path

IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def iter_images(path: str | Path):
    p = Path(path)
    if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES:
        yield p
    elif p.is_dir():
        for child in sorted(p.rglob("*")):
            if child.suffix.lower() in IMAGE_SUFFIXES:
                yield child
